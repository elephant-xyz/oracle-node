// Make exports work in Node < 12
// eslint-disable-next-line no-undef
module.exports = require("./dist/commonjs/sniffer.js");
